call D:\Tools\oss-cad-suite-windows\environment.bat" 
