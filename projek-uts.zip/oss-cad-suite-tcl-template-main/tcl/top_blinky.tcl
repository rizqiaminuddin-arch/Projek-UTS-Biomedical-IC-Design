# Initialize the Yosys-Tcl environment
yosys -import

# 1. Define Tcl variables (Sesuaikan dengan nama modul UTS Anda)
set top_level "top_tm1638_demo"
set src_files [list "tcl/top_tm1638_demo.v" "tcl/tm1638.v"]

# 2. Read input RTL files using a Tcl loop
# (Tulisan 'rtl/' dihapus agar Yosys membaca file langsung dari folder tcl)
foreach file $src_files {
    puts "Parsing source file: $file"
    read_verilog $file
}

# 3. Design Elaborate & Check
hierarchy -top $top_level
procs; # Executes Yosys RTL proc pass

# 4. Synthesize and optimize untuk papan iCESugar (Ice40)
# (Penting: harus menghasilkan output format .json untuk icepack)
synth_ice40 -top $top_level -json "build/${top_level}.json"

# 5. Print synthesis stats and save the gate-level netlist
stat
write_verilog "build/${top_level}_netlist.v"
write_verilog -noattr "build/${top_level}_netlist_noattr.v"