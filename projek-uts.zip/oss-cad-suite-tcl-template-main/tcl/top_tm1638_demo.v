module top_tm1638_demo(
    input clk,
    output reg tm_cs,
    output tm_clk,
    inout  tm_dio
);

    localparam HIGH = 1'b1, LOW = 1'b0;
    localparam [7:0] C_READ  = 8'b01000010;
    localparam [7:0] C_WRITE = 8'b01000000;
    localparam [7:0] C_DISP  = 8'b10001111;
    localparam [7:0] C_ADDR  = 8'b11000000;

    localparam CLK_DIV = 19; 

    reg rst = HIGH;
    reg [5:0] instruction_step;
    reg [CLK_DIV:0] counter;

    // 1. VARIABEL DATA & LOGIKA SWITCH UTS

    reg [7:0] keys;
    reg [7:0] prev_keys;
    reg [7:0] switch_val; // Menyimpan status tombol ON/OFF

    // 2. HEXADESIMAL

    function [7:0] hex_to_seg;
        input [3:0] nilai;
        begin
            case (nilai)
                4'h0: hex_to_seg = 8'h3F; // 0
                4'h1: hex_to_seg = 8'h06; // 1
                4'h2: hex_to_seg = 8'h5B; // 2
                4'h3: hex_to_seg = 8'h4F; // 3
                4'h4: hex_to_seg = 8'h66; // 4
                4'h5: hex_to_seg = 8'h6D; // 5
                4'h6: hex_to_seg = 8'h7D; // 6
                4'h7: hex_to_seg = 8'h07; // 7
                4'h8: hex_to_seg = 8'h7F; // 8
                4'h9: hex_to_seg = 8'h6F; // 9
                4'hA: hex_to_seg = 8'h77; // A
                4'hB: hex_to_seg = 8'h7C; // b
                4'hC: hex_to_seg = 8'h39; // C
                4'hD: hex_to_seg = 8'h5E; // d
                4'hE: hex_to_seg = 8'h79; // E
                4'hF: hex_to_seg = 8'h71; // F
                default: hex_to_seg = 8'h00;
            endcase
        end
    endfunction

    // 3. KONVERTER Biner ke Desimal

    reg [3:0] bcd_ratusan, bcd_puluhan, bcd_satuan;
    integer i;
    always @(*) begin
        bcd_ratusan = 4'd0;
        bcd_puluhan = 4'd0;
        bcd_satuan  = 4'd0;
        for (i = 7; i >= 0; i = i - 1) begin
            if (bcd_ratusan >= 5) bcd_ratusan = bcd_ratusan + 3;
            if (bcd_puluhan >= 5) bcd_puluhan = bcd_puluhan + 3;
            if (bcd_satuan  >= 5) bcd_satuan  = bcd_satuan  + 3;
            bcd_ratusan = {bcd_ratusan[2:0], bcd_puluhan[3]};
            bcd_puluhan = {bcd_puluhan[2:0], bcd_satuan[3]};
            bcd_satuan  = {bcd_satuan[2:0],  switch_val[i]};
        end
    end

    // 4. PENGATURAN PIN & PEMANGGILAN DRIVER TM1638

    reg tm_rw;
    wire dio_in, dio_out;
    SB_IO #(
        .PIN_TYPE(6'b101001),
        .PULLUP(1'b1)
    ) tm_dio_io (
        .PACKAGE_PIN(tm_dio),
        .OUTPUT_ENABLE(tm_rw),
        .D_IN_0(dio_in),
        .D_OUT_0(dio_out)
    );

    reg tm_latch;
    wire busy;
    wire [7:0] tm_data, tm_in;
    reg [7:0] tm_out;

    assign tm_in = tm_data;
    assign tm_data = tm_rw ? tm_out : 8'hZZ;

    tm1638 u_tm1638 (
        .clk(clk),
        .rst(rst),
        .data_latch(tm_latch),
        .data(tm_data),
        .rw(tm_rw),
        .busy(busy),
        .sclk(tm_clk),
        .dio_in(dio_in),
        .dio_out(dio_out)
    );

    task display_digit;
        input [7:0] segs;
        begin
            tm_latch <= HIGH;
            tm_out <= segs;
        end
    endtask

    task display_led;
        input isOn;
        begin
            tm_latch <= HIGH;
            tm_out <= isOn ? 8'h01 : 8'h00;
        end
    endtask

    always @(posedge clk) begin
        if (rst) begin
            instruction_step <= 6'b0;
            tm_cs <= HIGH;
            tm_rw <= HIGH;
            rst <= LOW;

            counter <= 0;
            keys <= 8'b0;
            prev_keys <= 8'b0;
            switch_val <= 8'b0;
        end else begin
            // Timing driver asli dipertahankan 100%
            if (counter[0] && ~busy) begin
                case (instruction_step)
                    // --- BACA TOMBOL ---
                    1:  {tm_cs, tm_rw}     <= {LOW, HIGH};
                    2:  {tm_latch, tm_out} <= {HIGH, C_READ};
                    3:  {tm_latch, tm_rw}  <= {HIGH, LOW};

                    4:  {keys[0], keys[4]} <= {tm_in[0], tm_in[4]};
                    5:  {tm_latch}         <= {HIGH};
                    6:  {keys[1], keys[5]} <= {tm_in[0], tm_in[4]};
                    7:  {tm_latch}         <= {HIGH};
                    8:  {keys[2], keys[6]} <= {tm_in[0], tm_in[4]};
                    9:  {tm_latch}         <= {HIGH};
                    10: {keys[3], keys[7]} <= {tm_in[0], tm_in[4]};
                    11: {tm_cs}            <= {HIGH};

                    // --- LOGIKA SAKELAR (TOGGLE) ---
                    12: begin
                        {tm_cs, tm_rw}     <= {LOW, HIGH};
                        if (keys[7] && !prev_keys[7]) switch_val[7] <= ~switch_val[7];
                        if (keys[6] && !prev_keys[6]) switch_val[6] <= ~switch_val[6];
                        if (keys[5] && !prev_keys[5]) switch_val[5] <= ~switch_val[5];
                        if (keys[4] && !prev_keys[4]) switch_val[4] <= ~switch_val[4];
                        if (keys[3] && !prev_keys[3]) switch_val[3] <= ~switch_val[3];
                        if (keys[2] && !prev_keys[2]) switch_val[2] <= ~switch_val[2];
                        if (keys[1] && !prev_keys[1]) switch_val[1] <= ~switch_val[1];
                        if (keys[0] && !prev_keys[0]) switch_val[0] <= ~switch_val[0];
                        prev_keys <= keys;
                    end

                    13: {tm_latch, tm_out} <= {HIGH, C_WRITE};
                    14: {tm_cs}            <= {HIGH};

                    15: {tm_cs, tm_rw}     <= {LOW, HIGH};
                    16: {tm_latch, tm_out} <= {HIGH, C_ADDR}; // Alamat 0
                    
                    // Sisi Kiri: Hexadesimal & LED 1-2
                    17: display_digit(hex_to_seg(switch_val[7:4])); 
                    18: display_led(switch_val[0]);                 // LED 1 (untuk S1)
                    19: display_digit(hex_to_seg(switch_val[3:0])); 
                    20: display_led(switch_val[1]);                 // LED 2 (untuk S2)

                    // Bagian Tengah: Kosong & LED 3-5
                    21: display_digit(8'h00);                       
                    22: display_led(switch_val[2]);                 // LED 3
                    23: display_digit(8'h00);                       
                    24: display_led(switch_val[3]);                 // LED 4
                    25: display_digit(8'h00);                       
                    26: display_led(switch_val[4]);                 // LED 5

                    // Sisi Kanan: Desimal BCD & LED 6-8
                    27: display_digit(hex_to_seg(bcd_ratusan));     
                    28: display_led(switch_val[5]);                 // LED 6
                    29: display_digit(hex_to_seg(bcd_puluhan));     
                    30: display_led(switch_val[6]);                 // LED 7
                    31: display_digit(hex_to_seg(bcd_satuan));      
                    32: display_led(switch_val[7]);                 // LED 8 (untuk S8)

                    33: {tm_cs}            <= {HIGH};

                    34: {tm_cs, tm_rw}     <= {LOW, HIGH};
                    35: {tm_latch, tm_out} <= {HIGH, C_DISP}; // Nyalakan layar
                    
                    // Reset siklus & manfaatkan overflow untuk jeda aman
                    36: {tm_cs, instruction_step} <= {HIGH, 6'b0}; 
                endcase

                instruction_step <= instruction_step + 1;

            end else if (busy) begin
                tm_latch <= LOW;
            end

            counter <= counter + 1;
        end
    end
endmodule